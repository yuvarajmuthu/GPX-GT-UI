import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gpx-fileupload',
  templateUrl: './gpx-fileupload.component.html',
  styleUrls: ['./gpx-fileupload.component.css']
})
export class GpxFileuploadComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
