import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-groupbiodatatemplate',
  templateUrl: './groupbiodatatemplate.component.html',
  styleUrls: ['./groupbiodatatemplate.component.css']
})
export class GroupbiodatatemplateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
