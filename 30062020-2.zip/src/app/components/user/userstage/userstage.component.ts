import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userstage',
  templateUrl: './userstage.component.html',
  styleUrls: ['./userstage.component.css']
})
export class UserstageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
