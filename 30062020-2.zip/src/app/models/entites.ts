export class Party {
	id:string;
	name: string;
	type: string;
	establishedDate: string;
	registeredAddress: string;
	ideology: string;
	profileImage: string;
}