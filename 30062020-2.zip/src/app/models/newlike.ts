export class NewLike {
    liked:boolean
}	
