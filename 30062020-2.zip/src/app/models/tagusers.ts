export class tagUser {
	username: string;
	name: string;
	img: string;
	type:string;
}