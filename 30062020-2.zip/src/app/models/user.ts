export class User {
    id: number;
    username: string; //email/phone
    password: string;
    firstName: string;
    lastName: string;
    emailId: string;
    phone: string;
    address: string;
    token?: string;
}